# QA History Log

> Reset on: 2026-05-16

| Date | Story ID | Pass Rate | Critical Bugs | Status | Report |
|---|---|---|---|---|---|
| 2026-05-16 | 1-1-opt-in-link-generation | 100% (18/18) | 2 fixed (validator not called, 500 on long name) | ✅ PASSED | TestResult/1-1-opt-in-link-generation/reports/qa-report.md |
| 2026-05-16 | 1-2-contact-auto-creation-via-opt-in-webhook | 100% (16/16 runnable, 1 skipped) | 1 fixed (BUG-001: optInStatus null — missing .Include), 1 pending (AC6 deactivate) | ✅ PASSED | TestResult/1-2-contact-auto-creation-via-opt-in-webhook/reports/qa-report.md |
| 2026-05-16 | 1-4-opt-in-link-management-dashboard | 100% (16/16) | 0 | ✅ PASSED | TestResult/1-4-opt-in-link-management-dashboard/reports/qa-report.md |
